function pdf = dac_ccs_linear(p0,p1,q0,q1,N,n)
%% [pdf, dlt, t] = dac_initial_spectrum(q, p, N, delta)
% p0,p1:  probability distribution of the source
% q0,q1:  lengths of enlarged intervals
% N:      number of segments
% dlt_th: threshold of successive MSE
% pdf:    discretized spectrum
% dlt:    real successive MSE
% t:      number of loops

pdf0 = zeros(1,N);
pdf1 = zeros(1,N);
pdf = zeros(n,N);
pdf(1,:) = ones(1,N);
for t=2:n
    for i=0:(N-1)
        i0 = i/q0; l0 = floor(i0); h0 = ceil(i0);
        if l0>(N-1)
            temp0 = 0;
        elseif h0>(N-1) || l0==h0
            temp0 = pdf(t-1,l0+1);
        else 
            temp0 = (h0-i0)*pdf(t-1,l0+1) + (i0-l0)*pdf(t-1,h0+1);
        end 
        pdf0(i+1) = temp0;
            
        i1 = (i-N*(1-q1))/q1; l1 = floor(i1); h1 = ceil(i1);
        if h1<0
            temp1 = 0;
        elseif l1<0 || l1==h1
            temp1 = pdf(t-1,h1+1);
        else 
            temp1 = (h1-i1)*pdf(t-1,l1+1) + (i1-l1)*pdf(t-1,h1+1);
        end       
        pdf1(i+1) = temp1;
    end
    pdf(t,:) = ((p0/q0)*pdf0 + (p1/q1)*pdf1);
    pdf(t,:) = pdf(t,:) * (N/sum(pdf(t,:)));
end