function pdf = dac_ccs_round(p0,p1,q0,q1,N,n)
%% [pdf, dlt, t] = dac_initial_spectrum(q, p, N, delta)
% p0,p1:  probability distribution of the source
% q0,q1:  lengths of enlarged intervals
% N:      number of segments
% dlt_th: threshold of successive MSE
% pdf:    discretized spectrum
% dlt:    real successive MSE
% t:      number of loops

pdf0 = zeros(1,N);
pdf1 = zeros(1,N);
pdf = zeros(n,N);
pdf(1,:) = ones(1,N);
for t=2:n
    for i=0:(N-1)
        i0 = round(i/q0);        
        if i0>=0 && i0<N
            pdf0(i+1) = pdf(t-1,i0+1);
        else
            pdf0(i+1) = 0;
        end 
            
        i1 = round((i-N*(1-q1))/q1);
        if i1>=0 && i1<N
            pdf1(i+1) = pdf(t-1,i1+1);
        else 
            pdf1(i+1) = 0;
        end       
    end
    pdf(t,:) = ((p0/q0)*pdf0 + (p1/q1)*pdf1);
    pdf(t,:) = pdf(t,:) * (N/sum(pdf(t,:)));
end