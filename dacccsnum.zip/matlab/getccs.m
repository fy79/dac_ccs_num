function ccs = getccs(ccs, p, r)
[n,nsegs] = size(ccs);
assert(n==length(r));

scaleup0 = (1-p).^(-r);
scaleup1 = p.^(-r);
shift = nsegs*(1-p.^r);

for i=2:n
    for j=1:nsegs
        alpha = (j-1)*scaleup0(i-1);
        beta = j*scaleup0(i-1);
        k = floor(alpha);
        l = floor(beta);
        if(k<nsegs)
            ccs(i,j) = (1-p)*(1-(alpha-k))*ccs(i-1,k+1);
        else
            break;
        end
        if(l<nsegs)
            ccs(i,j) = ccs(i,j) + (1-p)*(beta-l)*ccs(i-1,l+1);
        end
        if((l-k)==2 && (k+1)<nsegs)
            ccs(i,j) = ccs(i,j) + (1-p)*ccs(i-1,k+2);
        end
    end

    for j=nsegs:-1:1
        alpha = (j-1-shift(i-1))*scaleup1(i-1);
        beta = (j-shift(i-1))*scaleup1(i-1);
        k = ceil(alpha);
        l = ceil(beta);
        if(l>0)
            ccs(i,j) = ccs(i,j) + p*(1-(l-beta))*ccs(i-1,l);
        else
            break;
        end
        if(k>0)
            ccs(i,j) = ccs(i,j) + p*(k-alpha)*ccs(i-1,k);
        end
        if((l-k)==2 && (l-1)>0)
            ccs(i,j) = ccs(i,j) + p*ccs(i-1,l-1);
        end
    end
end