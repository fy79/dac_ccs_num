function ccs = getccs(ccs,p,r)
%% Note that ccs(i,j) is the approximate of \int_{(j-1)/m}^{j/m}f_i(u)du, 
%% rather than \int_{j/m}^{(j+1)/m}f_i(u)du, 
%% because in MATLAB, an array is indexed from 1 rather than 0.
[n,m] = size(ccs);
assert(n==length(r));

scaleup0 = (1-p).^(-r);
scaleup1 = p.^(-r);
shift = m*(1-p.^r);

for i=2:n
    for j=1:m
        alpha = (j-1)*scaleup0(i-1);
        if alpha<m
            k = floor(alpha);   
            ccs(i,j) = (1-p)*((k+1)-alpha)*ccs(i-1,k+1);    % 0 < ((k+1)-alpha) <= 1
            
            beta = j*scaleup0(i-1);
            l = floor(beta);
            ccs(i,j) = ccs(i,j) + (1-p)*sum(ccs(i-1,(k+2):min(l,m)));
            
            if l<m % l <= beta < m
                ccs(i,j) = ccs(i,j) + (1-p)*(beta-l)*ccs(i-1,l+1);  % 0 <= (beta-l) < 1
            end
        else
            break;
        end
    end

    for j=m:-1:1
        beta = (j-shift(i-1))*scaleup1(i-1);
        if beta>0
            l = ceil(beta);    
            ccs(i,j) = ccs(i,j) + p*(beta-(l-1))*ccs(i-1,l);    % 0 < (beta-(l-1)) <= 1
            
            alpha = ((j-1)-shift(i-1))*scaleup1(i-1);
            k = ceil(alpha); 
            ccs(i,j) = ccs(i,j) + p*sum(ccs(i-1,max(1,(k+1)):(l-1)));

            if k>0 % 0<alpha<=k
                ccs(i,j) = ccs(i,j) + p*(k-alpha)*ccs(i-1,k);   % 0 <= (k-alpha) < 1
            end
        else
            break;
        end
    end
end