n = 128;
m = 2^10;
u = (0:(m-1))/m;
t = 0;
r = [0.5*ones(n-t,1);ones(t,1)];
p = 0.5;
ccs = zeros(n,m);
ccs(1,:) = 1;
ccs = getccs(ccs, p, r);
pdf = dac_ccs_linear(1-p,p,(1-p)^0.5,p^0.5,m,n);
pdfrnd = dac_ccs_round(1-p,p,(1-p)^0.5,p^0.5,m,n);

figure(1);
plot(u,ccs(1,:)); hold on;
plot(u,ccs(2,:)); 
plot(u,ccs(3,:)); 
plot(u,ccs(4,:));
grid on;
axis tight;
set(gca, 'FontSize', 24);
title({'Fair Numerical Algorithm'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{n-i}(u)$'}, 'interpreter', 'latex');
legend({'$i=0$','$i=1$','$i=2$','$i=3$'}, 'interpreter', 'latex');

figure(2);
plot(u,ccs(9,:)); hold on;
plot(u,ccs(17,:)); 
plot(u,ccs(33,:)); 
plot(u,ccs(65,:));
grid on;
axis tight;
set(gca, 'FontSize', 24);
title({'Fair Numerical Algorithm'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{n-i}(u)$'}, 'interpreter', 'latex');
legend({'$i=8$','$i=16$','$i=32$','$i=64$'}, 'interpreter', 'latex');
% create smaller axes in top right, and plot on it
axes('Position',[.368 .2 .3 .3])
box on;
x2 = ((m/2-m/128):(m/2+m/128-1))/m;
y2a = ccs(9,(m/2-m/128+1):(m/2+m/128));
y2b = ccs(17,(m/2-m/128+1):(m/2+m/128));
y2c = ccs(33,(m/2-m/128+1):(m/2+m/128));
y2d = ccs(65,(m/2-m/128+1):(m/2+m/128));
plot(x2,y2a); hold on;
plot(x2,y2b);
plot(x2,y2c);
plot(x2,y2d);
grid on;
axis tight;


figure(3);
plot(u,pdf(1,:)); hold on;
plot(u,pdf(2,:)); 
plot(u,pdf(3,:)); 
plot(u,pdf(4,:));
grid on;
axis tight;
set(gca, 'FontSize', 24);
title({'Linear Numerical Algorithm'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{n-i}(u)$'}, 'interpreter', 'latex');
legend({'$i=0$','$i=1$','$i=2$','$i=3$'}, 'interpreter', 'latex');

figure(4);
plot(u,pdf(9,:)); hold on;
plot(u,pdf(17,:)); hold on;
plot(u,pdf(33,:)); 
plot(u,pdf(65,:));
grid on;
axis tight;
set(gca, 'FontSize', 24);
title({'Linear Numerical Algorithm'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{n-i}(u)$'}, 'interpreter', 'latex');
legend({'$i=8$','$i=16$','$i=32$','$i=64$'}, 'interpreter', 'latex');
% create smaller axes in top right, and plot on it
axes('Position',[.368 .2 .3 .3])
box on;
x2 = ((m/2-m/128):(m/2+m/128-1))/m;
y2a = pdf(9,(m/2-m/128+1):(m/2+m/128));
y2b = pdf(17,(m/2-m/128+1):(m/2+m/128));
y2c = pdf(33,(m/2-m/128+1):(m/2+m/128));
y2d = pdf(65,(m/2-m/128+1):(m/2+m/128));
plot(x2,y2a); hold on;
plot(x2,y2b);
plot(x2,y2c);
plot(x2,y2d);
grid on;
axis tight;


figure(5);
plot(u,pdfrnd(1,:)); hold on;
plot(u,pdfrnd(2,:)); 
plot(u,pdfrnd(3,:)); 
plot(u,pdfrnd(4,:));
grid on;
axis tight;
set(gca, 'FontSize', 24);
title({'Rounding Numerical Algorithm'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{n-i}(u)$'}, 'interpreter', 'latex');
legend({'$i=0$','$i=1$','$i=2$','$i=3$'}, 'interpreter', 'latex');

figure(6);
plot(u,pdfrnd(9,:)); hold on;
plot(u,pdfrnd(17,:)); hold on;
plot(u,pdfrnd(33,:)); 
plot(u,pdfrnd(65,:));
grid on;
axis tight;
set(gca, 'FontSize', 24);
title({'Rounding Numerical Algorithm'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{n-i}(u)$'}, 'interpreter', 'latex');
legend({'$i=8$','$i=16$','$i=32$','$i=64$'}, 'interpreter', 'latex');
% create smaller axes in top right, and plot on it
axes('Position',[.368 .2 .3 .3])
box on;
x2 = ((m/2-m/128):(m/2+m/128-1))/m;
y2a = pdfrnd(9,(m/2-m/128+1):(m/2+m/128));
y2b = pdfrnd(17,(m/2-m/128+1):(m/2+m/128));
y2c = pdfrnd(33,(m/2-m/128+1):(m/2+m/128));
y2d = pdfrnd(65,(m/2-m/128+1):(m/2+m/128));
plot(x2,y2a); hold on;
plot(x2,y2b);
plot(x2,y2c);
plot(x2,y2d);
grid on;
axis tight;